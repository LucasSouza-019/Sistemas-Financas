import { Request, Response } from 'express';
import pool from '../db';
import db from '../db'; // conexão com banco

// Registra um novo gasto
async function registrarGasto(req: Request, res: Response) {
  const { descricao, categoria, valor} = req.body;

  if (!descricao || !categoria  || !valor) {
    return res.status(400).json({ mensagem: 'Descrição, Categoria e valor são obrigatórios.' });
  }

  try {
    const data = new Date();

    // Insere o novo gasto no banco de dados
    const [result] = await pool.query(
      'INSERT INTO gastos (descricao, categoria, valor, data) VALUES (?, ?, ?, ?)',
      [descricao, categoria, valor, data]
    );

    res.status(201).json({
      mensagem: 'Gasto registrado com sucesso!',
      gasto: { id: (result as any).insertId, descricao, categoria, valor, data }
    });
  } catch (error) {
    console.error('Erro ao registrar gasto:', error);
    res.status(500).json({ mensagem: 'Erro ao registrar gasto.' });
  }
}
// Lista todos os gastos
async function listarGastos(req: Request, res: Response) {
  try {
    // Busca todos os gastos no banco de dados
    const [rows] = await pool.query('SELECT * FROM gastos ORDER BY data DESC');

    res.status(200).json(rows);
  } catch (error) {
    console.error('Erro ao listar gastos:', error);
    res.status(500).json({ mensagem: 'Erro ao listar gastos.' });
  }
}
// // // // // // // // // // // // // // // // // // // // // // // // // // 

// ✏️ Atualiza um gasto existente pelo ID
async function atualizarGasto(req: Request, res: Response) {
    const id = parseInt(req.params.id);
    const { descricao, categoria, valor  } = req.body;
  
    try {
      const [result] = await db.execute(
        'UPDATE gastos SET descricao = ?, categoria = ?, valor = ? WHERE id = ?',
        [descricao, categoria, valor,  id]
      );
  
      // Verifica se alguma linha foi afetada
      // @ts-ignore
      if (result.affectedRows === 0) {
        return res.status(404).json({ mensagem: 'Gasto não encontrado.' });
      }
  
      res.status(200).json({ mensagem: 'Gasto atualizado com sucesso!' });
    } catch (erro) {
      res.status(500).json({ erro: 'Erro ao atualizar gasto.' });
    }
  }
// // // // // // // // // // // // // // // // // // // // // // // // // // 


// 🗑️ Excluir um gasto
async function excluirGasto(req: Request, res: Response) {
    // 🔹 Captura o ID da URL (ex: /gastos/3 → id = 3)
    const id = parseInt(req.params.id);
  
    // 🔸 Verifica se o ID é realmente um número válido
    if (isNaN(id)) {
      // ⚠️ Se não for, responde com erro 400 (requisição inválida)
      return res.status(400).json({ mensagem: 'ID inválido.' });
    }
  
    try {
      // 🔹 Executa o comando DELETE no banco, substituindo o ? pelo ID
      const [resultado] = await pool.execute(
        'DELETE FROM gastos WHERE id = ?',
        [id]
      );
  
      // 🔸 O resultado da query vem num array, aqui forçamos o tipo para acessar `affectedRows`
      const info: any = resultado;
  
      // ❗ Se `affectedRows` for 0, quer dizer que nenhum gasto foi encontrado com aquele ID
      if (info.affectedRows === 0) {
        return res.status(404).json({ mensagem: 'Gasto não encontrado.' });
      }
  
      // ✅ Se passou, quer dizer que o gasto foi excluído com sucesso
      res.status(200).json({ mensagem: 'Gasto excluído com sucesso!' });
    } catch (erro) {
      // 🛑 Se deu erro inesperado, mostra no console e envia erro 500
      console.error(erro);
      res.status(500).json({ mensagem: 'Erro ao excluir gasto.' });
    }
  }
// // // // // // // // // // // // // // // // // // // // // // // // // // 

// 🔍 Filtrar gastos por período

async function filtrarGastosPorPeriodo(req: Request, res: Response) {
    // Captura as datas da query string (ex: /gastos/filtro?inicio=2024-03-01&fim=2024-03-31)
    const { inicio, fim } = req.query;
  
    // Verifica se ambas as datas foram fornecidas
    if (!inicio || !fim) {
      return res.status(400).json({
        mensagem: 'Informe as datas de início e fim no formato YYYY-MM-DD.',
      });
    }
  
    try {
      // Executa a consulta SQL buscando gastos entre as datas fornecidas
      const [rows] = await pool.execute(
        'SELECT * FROM gastos WHERE data BETWEEN ? AND ?',
        [inicio, fim]
      );
  
      // Se não encontrar nenhum gasto, retorna uma mensagem amigável
      if ((rows as any[]).length === 0) {
        return res.status(404).json({
          mensagem: 'Nenhum gasto encontrado nesse período.',
        });
      }
  
      // Retorna os gastos encontrados no período
      res.status(200).json(rows);
    } catch (erro) {
      console.error(erro); // Loga o erro no terminal
      res.status(500).json({
        mensagem: 'Erro ao buscar gastos por período.',
      });
    }
  }

  // // // // // // // // // // // // // // // // // // // // // // // // // // 
// 🔍 Filtra os gastos por categoria
async function filtrarPorCategoria(req: Request, res: Response) {
    // Pegamos a categoria da query string, ex: /gastos/categoria?categoria=comida
    const categoria = req.query.categoria as string;
  
    // Verificamos se a categoria foi enviada
    if (!categoria) {
      return res.status(400).json({ mensagem: 'Informe a categoria a ser filtrada.' });
    }
  
    try {
      // Consulta os gastos filtrando pela categoria
      const [resultado] = await pool.execute(
        'SELECT * FROM gastos WHERE categoria = ? ORDER BY data DESC',
        [categoria]
      );
  
      const gastos = resultado as any[];
  
      // Se não encontrou nada, avisa o usuário
      if (gastos.length === 0) {
        return res.status(404).json({ mensagem: `Nenhum gasto encontrado na categoria "${categoria}".` });
      }
  
      // Retorna os gastos encontrados
      res.status(200).json(gastos);
    } catch (erro) {
      console.error(erro);
      res.status(500).json({ mensagem: 'Erro ao buscar gastos por categoria.' });
    }
  }
  // // // // // // // // // // // // // // // // // // // // // // // // // // 
// 📅 Função que calcula o total gasto no mês atual
async function totalMesAtual(req: Request, res: Response) {
  try {
    const hoje = new Date();

    // Define o primeiro dia do mês
    const primeiroDia = new Date(hoje.getFullYear(), hoje.getMonth(), 1);

    // Define o último dia do mês (com horário máximo)
    const ultimoDia = new Date(hoje.getFullYear(), hoje.getMonth() + 1, 0, 23, 59, 59);

    // Executa a soma no banco de dados
    const [linhas]: any = await pool.execute(
      'SELECT SUM(valor) AS total FROM gastos WHERE data BETWEEN ? AND ?',
      [primeiroDia, ultimoDia]
    );

    const total = linhas[0].total || 0;

    res.status(200).json({ total: Number(total) });
  } catch (erro) {
    console.error(erro);
    res.status(500).json({ mensagem: 'Erro ao calcular o total do mês.' });
  }
}

// Total gasto por categoria no mês atual
async function resumoPorCategoria(req: Request, res: Response) {
  try {
    // Consulta SQL: soma dos gastos agrupados por categoria, no mês atual
    const [resultado] = await pool.execute(
      `SELECT categoria, SUM(valor) AS total
       FROM gastos
       WHERE MONTH(data) = MONTH(CURDATE()) AND YEAR(data) = YEAR(CURDATE())
       GROUP BY categoria`
    );

    res.status(200).json(resultado);
  } catch (erro) {
    console.error(erro);
    res.status(500).json({ mensagem: 'Erro ao gerar resumo por categoria.' });
  }
}

// 💰 Retorna o total gasto em um período
async function totalGastosPorPeriodo(req: Request, res: Response) {
  const { inicio, fim } = req.query;

  // ✅ Validação: datas obrigatórias
  if (!inicio || !fim) {
    return res.status(400).json({ mensagem: 'Informe as datas de início e fim no formato YYYY-MM-DD.' });
  }

  try {
    // 🟡 Consulta SQL para somar os valores
    const [linhas] = await pool.execute(
      'SELECT SUM(valor) AS total FROM gastos WHERE data BETWEEN ? AND ?',
      [inicio, fim]
    );

    const resultado: any = linhas;

    // 🛑 Caso não tenha nenhum gasto
    const total = resultado[0].total;
    if (total === null) {
      return res.status(200).json({ mensagem: 'Nenhum gasto registrado nesse período.', total: 0 });
    }

    // ✅ Retorna o total
    res.status(200).json({ total });

  } catch (erro) {
    console.error(erro);
    res.status(500).json({ mensagem: 'Erro ao calcular o total de gastos no período.' });
  }
}



export { registrarGasto, listarGastos, atualizarGasto, excluirGasto, 
  filtrarGastosPorPeriodo,filtrarPorCategoria, 
  totalMesAtual, resumoPorCategoria, totalGastosPorPeriodo };
