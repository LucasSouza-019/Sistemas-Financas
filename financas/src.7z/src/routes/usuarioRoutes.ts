const express = require('express');
const router = express.Router();

const { cadastrarUsuario, loginUsuario } = require('../controllers/chatbotController');

router.post('/cadastro', cadastrarUsuario);
router.post('/login', loginUsuario);

export default router;
