const express = require('express');
const router = express.Router();

const { interpretarMensagem } = require('../controllers/chatbotController');

router.post('/chatbot', interpretarMensagem);

module.exports = router;