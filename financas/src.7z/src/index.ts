import express from 'express';
import gastosRoutes from './routes/gastosRoutes';
import usuarioRoutes from './routes/usuarioRoutes';
import chatbotRoutes from './routes/chatbotRoutes';


const app = express();
const port = 3000;

app.use(express.json());

app.use('/gastos', gastosRoutes);
app.use(chatbotRoutes);
app.use('/usuarios', usuarioRoutes);

app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
